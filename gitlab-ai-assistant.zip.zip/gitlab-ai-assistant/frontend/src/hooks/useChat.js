import { useState, useCallback, useRef } from 'react'
import axios from 'axios'

function generateId() {
  return Math.random().toString(36).substring(2, 10)
}

function getOrCreateConversationId() {
  let id = sessionStorage.getItem('gitlab_conversation_id')
  if (!id) {
    id = generateId()
    sessionStorage.setItem('gitlab_conversation_id', id)
  }
  return id
}

export function useChat() {
  const [messages, setMessages] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState(null)
  const conversationIdRef = useRef(getOrCreateConversationId())

  const sendMessage = useCallback(async (text) => {
    if (!text || !text.trim()) return

    const userMessage = {
      id: generateId(),
      role: 'user',
      content: text.trim(),
      timestamp: new Date().toISOString(),
    }

    setMessages(prev => [...prev, userMessage])
    setIsLoading(true)
    setError(null)

    const history = messages.slice(-6).map(m => ({
      role: m.role,
      content: m.content,
    }))

    try {
      const response = await axios.post('/api/chat', {
        message: text.trim(),
        conversation_id: conversationIdRef.current,
        history,
      })

      const { answer, sources, tokens_used } = response.data

      const assistantMessage = {
        id: generateId(),
        role: 'assistant',
        content: answer,
        sources: sources || [],
        timestamp: new Date().toISOString(),
        tokens: tokens_used || 0,
      }

      setMessages(prev => [...prev, assistantMessage])
    } catch (err) {
      const detail = err.response?.data?.detail || err.message || 'Unknown error'
      const errorMessage = {
        id: generateId(),
        role: 'error',
        content: detail,
        timestamp: new Date().toISOString(),
      }
      setMessages(prev => [...prev, errorMessage])
      setError(detail)
    } finally {
      setIsLoading(false)
    }
  }, [messages])

  const clearChat = useCallback(() => {
    setMessages([])
    setIsLoading(false)
    setError(null)
    conversationIdRef.current = generateId()
    sessionStorage.setItem('gitlab_conversation_id', conversationIdRef.current)
  }, [])

  return {
    messages,
    isLoading,
    error,
    conversationId: conversationIdRef.current,
    sendMessage,
    clearChat,
  }
}
