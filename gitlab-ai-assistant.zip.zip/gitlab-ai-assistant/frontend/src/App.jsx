import { useState } from 'react'
import Header from './components/Header'
import Sidebar from './components/Sidebar'
import ChatWindow from './components/ChatWindow'
import InputBar from './components/InputBar'
import { useChat } from './hooks/useChat'

export default function App() {
  const { messages, isLoading, sendMessage, clearChat } = useChat()
  const [prefillText, setPrefillText] = useState('')

  const handleSuggestionClick = (text) => {
    setPrefillText(text)
  }

  const handlePrefillClear = () => {
    setPrefillText('')
  }

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        background: 'var(--bg-primary)',
        overflow: 'hidden',
      }}
    >
      <Header />

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        <Sidebar onSuggestionClick={handleSuggestionClick} />

        <main
          style={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
            position: 'relative',
          }}
        >
          {/* Clear chat button */}
          {messages.length > 0 && (
            <div
              style={{
                position: 'absolute',
                top: 12,
                right: 16,
                zIndex: 10,
              }}
            >
              <button
                onClick={clearChat}
                className="px-3 py-1.5 rounded-lg text-xs"
                style={{
                  background: 'var(--bg-card)',
                  border: '1px solid var(--border)',
                  color: 'var(--text-muted)',
                  cursor: 'pointer',
                  fontFamily: 'DM Sans, sans-serif',
                  transition: 'all 200ms ease',
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.borderColor = 'var(--error)'
                  e.currentTarget.style.color = 'var(--error)'
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.borderColor = 'var(--border)'
                  e.currentTarget.style.color = 'var(--text-muted)'
                }}
              >
                Clear chat
              </button>
            </div>
          )}

          <ChatWindow
            messages={messages}
            isLoading={isLoading}
            onQuestionClick={handleSuggestionClick}
          />

          <InputBar
            onSend={sendMessage}
            isLoading={isLoading}
            prefillText={prefillText}
            onPrefillClear={handlePrefillClear}
          />
        </main>
      </div>
    </div>
  )
}
