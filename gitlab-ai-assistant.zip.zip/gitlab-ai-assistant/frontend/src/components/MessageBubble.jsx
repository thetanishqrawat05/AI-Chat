import { motion } from 'framer-motion'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { AlertCircle, RefreshCw } from 'lucide-react'
import SourceCard from './SourceCard'

function formatTime(iso) {
  try {
    return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  } catch {
    return ''
  }
}

function GitLabFoxAvatar() {
  return (
    <div
      className="flex items-center justify-center rounded-full flex-shrink-0"
      style={{
        width: 32,
        height: 32,
        background: 'var(--accent-glow)',
        border: '1px solid var(--accent)',
      }}
    >
      <svg width="18" height="18" viewBox="0 0 60 60" fill="none">
        <path d="M30 52L8 22l5-14 7 14h20l7-14 5 14L30 52z" fill="#e5673a" opacity="0.95"/>
        <path d="M30 52L15 22h30L30 52z" fill="#c8531f"/>
        <path d="M8 22L13 8l7 14H8z" fill="#f0774a"/>
        <path d="M52 22L47 8l-7 14h12z" fill="#f0774a"/>
        <circle cx="22" cy="20" r="2" fill="#0a0a0f"/>
        <circle cx="38" cy="20" r="2" fill="#0a0a0f"/>
      </svg>
    </div>
  )
}

function UserAvatar() {
  return (
    <div
      className="flex items-center justify-center rounded-full flex-shrink-0 text-xs font-bold"
      style={{
        width: 32,
        height: 32,
        background: 'var(--accent)',
        color: '#fff',
        fontFamily: 'Syne, sans-serif',
        fontSize: '0.7rem',
        letterSpacing: '0.05em',
      }}
    >
      YOU
    </div>
  )
}

export default function MessageBubble({ message, onRetry }) {
  const { role, content, sources, timestamp, tokens } = message

  if (role === 'error') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25 }}
        className="flex items-start gap-3 px-4 py-2"
      >
        <div
          className="flex items-center justify-center rounded-full flex-shrink-0"
          style={{
            width: 32, height: 32,
            background: 'rgba(248, 113, 113, 0.1)',
            border: '1px solid var(--error)',
          }}
        >
          <AlertCircle size={14} style={{ color: 'var(--error)' }} />
        </div>
        <div
          className="rounded-2xl rounded-tl-sm px-4 py-3 flex-1"
          style={{
            background: 'rgba(248, 113, 113, 0.05)',
            border: '1px solid rgba(248, 113, 113, 0.3)',
          }}
        >
          <p style={{ fontSize: '0.85rem', color: 'var(--error)', marginBottom: 8 }}>
            {content}
          </p>
          {onRetry && (
            <button
              onClick={onRetry}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs"
              style={{
                background: 'rgba(248, 113, 113, 0.1)',
                border: '1px solid rgba(248, 113, 113, 0.3)',
                color: 'var(--error)',
                cursor: 'pointer',
              }}
            >
              <RefreshCw size={11} />
              Try again
            </button>
          )}
        </div>
      </motion.div>
    )
  }

  if (role === 'user') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25 }}
        className="flex items-start gap-3 px-4 py-2 justify-end"
      >
        <div className="flex flex-col items-end gap-1">
          <div
            className="rounded-2xl rounded-tr-sm px-4 py-2.5"
            style={{
              background: 'var(--user-bubble)',
              border: '1px solid var(--border-light)',
              maxWidth: 560,
            }}
          >
            <p style={{ fontSize: '0.9rem', color: 'var(--text-primary)', lineHeight: 1.6, margin: 0 }}>
              {content}
            </p>
          </div>
          <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)', paddingRight: 4 }}>
            {formatTime(timestamp)}
          </span>
        </div>
        <UserAvatar />
      </motion.div>
    )
  }

  // Assistant message
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="flex items-start gap-3 px-4 py-2"
    >
      <GitLabFoxAvatar />
      <div className="flex flex-col gap-1 flex-1 min-w-0">
        <div
          className="rounded-2xl rounded-tl-sm px-4 py-3"
          style={{
            background: 'var(--ai-bubble)',
            border: '1px solid var(--border)',
          }}
        >
          <div className="prose-dark">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {content}
            </ReactMarkdown>
          </div>
          <SourceCard sources={sources} />
        </div>
        <div className="flex items-center gap-3 pl-1">
          <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>
            {formatTime(timestamp)}
          </span>
          {tokens > 0 && (
            <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>
              ~{tokens} tokens
            </span>
          )}
        </div>
      </div>
    </motion.div>
  )
}
