import { ExternalLink, Info } from 'lucide-react'

function shortenDomain(url) {
  try {
    const u = new URL(url)
    return u.hostname.replace('www.', '') + (u.pathname.length > 1 ? u.pathname.slice(0, 20) + (u.pathname.length > 20 ? '…' : '') : '')
  } catch {
    return url.slice(0, 30)
  }
}

export default function SourceCard({ sources }) {
  if (!sources || sources.length === 0) return null

  return (
    <div className="mt-3">
      <div className="flex items-center gap-1.5 mb-2">
        <Info size={11} style={{ color: 'var(--text-muted)' }} />
        <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 500, letterSpacing: '0.05em', textTransform: 'uppercase' }}>
          Sources
        </span>
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
        {sources.map((source, i) => (
          <a
            key={i}
            href={source.url}
            target="_blank"
            rel="noopener noreferrer"
            title={source.snippet}
            className="source-card flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg flex-shrink-0"
            style={{
              background: 'var(--bg-card)',
              border: '1px solid var(--border)',
              textDecoration: 'none',
              maxWidth: 200,
            }}
          >
            <ExternalLink size={10} style={{ color: 'var(--accent)', flexShrink: 0 }} />
            <span style={{
              fontSize: '0.72rem',
              color: 'var(--text-secondary)',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}>
              {shortenDomain(source.url)}
            </span>
          </a>
        ))}
      </div>
    </div>
  )
}
