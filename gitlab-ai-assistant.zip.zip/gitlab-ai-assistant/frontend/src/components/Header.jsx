import { useEffect, useState } from 'react'
import { Star, Zap } from 'lucide-react'
import axios from 'axios'

function GitLabFoxIcon({ size = 28 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M30 52L8 22l5-14 7 14h20l7-14 5 14L30 52z" fill="#e5673a" opacity="0.95"/>
      <path d="M30 52L15 22h30L30 52z" fill="#c8531f"/>
      <path d="M8 22L13 8l7 14H8z" fill="#f0774a"/>
      <path d="M52 22L47 8l-7 14h12z" fill="#f0774a"/>
      <circle cx="22" cy="20" r="2.5" fill="#0a0a0f"/>
      <circle cx="38" cy="20" r="2.5" fill="#0a0a0f"/>
      <path d="M24 28 Q30 33 36 28" stroke="#0a0a0f" strokeWidth="1.5" strokeLinecap="round" fill="none"/>
    </svg>
  )
}

export default function Header() {
  const [status, setStatus] = useState({ status: 'loading', message: '' })

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await axios.get('/api/status')
        setStatus(res.data)
      } catch {
        setStatus({ status: 'error', message: 'Cannot connect to API' })
      }
    }
    fetchStatus()
    const interval = setInterval(fetchStatus, 8000)
    return () => clearInterval(interval)
  }, [])

  const statusColor = {
    ready: '#3ecf8e',
    indexing: '#f59e0b',
    error: '#f87171',
    loading: '#555568',
  }[status.status] || '#555568'

  const statusLabel = {
    ready: 'Ready',
    indexing: 'Indexing...',
    error: 'Error',
    loading: 'Connecting...',
  }[status.status] || 'Unknown'

  return (
    <header
      className="glass sticky top-0 z-50"
      style={{
        borderBottom: '1px solid var(--border)',
        borderTop: '2px solid var(--accent)',
      }}
    >
      <div className="flex items-center justify-between px-4 py-3 max-w-full">
        {/* Left: Logo + Title */}
        <div className="flex items-center gap-3">
          <GitLabFoxIcon size={32} />
          <div>
            <h1
              style={{
                fontFamily: 'Syne, sans-serif',
                fontWeight: 700,
                fontSize: '1.1rem',
                color: 'var(--text-primary)',
                lineHeight: 1.2,
              }}
            >
              GitLab AI Assistant
            </h1>
            <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: '1px' }}>
              Handbook & Direction Intelligence
            </p>
          </div>
        </div>

        {/* Center: Status */}
        <div
          className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full"
          style={{
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
            fontSize: '0.78rem',
          }}
        >
          <span
            style={{
              width: 7,
              height: 7,
              borderRadius: '50%',
              background: statusColor,
              display: 'inline-block',
              boxShadow: status.status === 'ready' ? `0 0 6px ${statusColor}` : 'none',
              animation: status.status === 'indexing' ? 'pulse 1.5s infinite' : 'none',
            }}
          />
          <span style={{ color: 'var(--text-secondary)' }}>{statusLabel}</span>
        </div>

        {/* Right: Gemini badge */}
        <div
          className="flex items-center gap-2 px-3 py-1.5 rounded-full"
          style={{
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
            fontSize: '0.75rem',
          }}
        >
          <Star size={12} style={{ color: '#4285f4' }} fill="#4285f4" />
          <span style={{ color: 'var(--text-secondary)' }}>
            <span style={{ color: '#4285f4' }}>G</span>
            <span style={{ color: '#ea4335' }}>o</span>
            <span style={{ color: '#fbbc04' }}>o</span>
            <span style={{ color: '#4285f4' }}>g</span>
            <span style={{ color: '#34a853' }}>l</span>
            <span style={{ color: '#ea4335' }}>e</span>
          </span>
          <span style={{ color: 'var(--text-muted)', fontWeight: 500 }}>Gemini</span>
        </div>
      </div>
    </header>
  )
}
