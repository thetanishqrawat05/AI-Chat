import { useEffect, useRef } from 'react'
import MessageBubble from './MessageBubble'
import TypingIndicator from './TypingIndicator'

const EXAMPLE_QUESTIONS = [
  "What are GitLab's core values?",
  "How does GitLab approach remote work?",
  "What is GitLab's engineering culture?",
]

function EmptyState({ onQuestionClick }) {
  return (
    <div className="flex flex-col items-center justify-center h-full px-4 py-12">
      <div className="flex flex-col items-center gap-6 max-w-md text-center">
        {/* Large fox icon */}
        <div
          className="flex items-center justify-center rounded-2xl"
          style={{
            width: 80,
            height: 80,
            background: 'var(--accent-glow)',
            border: '1px solid rgba(229, 103, 58, 0.3)',
          }}
        >
          <svg width="50" height="50" viewBox="0 0 60 60" fill="none">
            <path d="M30 52L8 22l5-14 7 14h20l7-14 5 14L30 52z" fill="#e5673a" opacity="0.95"/>
            <path d="M30 52L15 22h30L30 52z" fill="#c8531f"/>
            <path d="M8 22L13 8l7 14H8z" fill="#f0774a"/>
            <path d="M52 22L47 8l-7 14h12z" fill="#f0774a"/>
            <circle cx="22" cy="20" r="2.5" fill="#0a0a0f"/>
            <circle cx="38" cy="20" r="2.5" fill="#0a0a0f"/>
            <path d="M24 28 Q30 33 36 28" stroke="#0a0a0f" strokeWidth="1.5" strokeLinecap="round" fill="none"/>
          </svg>
        </div>

        <div>
          <h2
            style={{
              fontFamily: 'Syne, sans-serif',
              fontSize: '1.5rem',
              fontWeight: 700,
              color: 'var(--text-primary)',
              marginBottom: 8,
            }}
          >
            Ask me anything about GitLab
          </h2>
          <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
            I have knowledge from GitLab's Handbook and Direction pages — values, engineering, product, and more.
          </p>
        </div>

        {/* Example question pills */}
        <div className="flex flex-wrap gap-2 justify-center">
          {EXAMPLE_QUESTIONS.map((q, i) => (
            <button
              key={i}
              onClick={() => onQuestionClick(q)}
              className="px-3 py-2 rounded-full text-sm"
              style={{
                background: 'var(--bg-card)',
                border: '1px solid var(--border-light)',
                color: 'var(--text-secondary)',
                cursor: 'pointer',
                transition: 'all 200ms ease',
                fontFamily: 'DM Sans, sans-serif',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = 'var(--accent)'
                e.currentTarget.style.color = 'var(--accent)'
                e.currentTarget.style.background = 'var(--accent-glow)'
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = 'var(--border-light)'
                e.currentTarget.style.color = 'var(--text-secondary)'
                e.currentTarget.style.background = 'var(--bg-card)'
              }}
            >
              {q}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

export default function ChatWindow({ messages, isLoading, onQuestionClick, lastUserMessage }) {
  const bottomRef = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isLoading])

  return (
    <div className="flex-1 overflow-y-auto dot-grid-bg" style={{ minHeight: 0 }}>
      {messages.length === 0 ? (
        <EmptyState onQuestionClick={onQuestionClick} />
      ) : (
        <div className="py-4 flex flex-col gap-1">
          {messages.map(msg => (
            <MessageBubble key={msg.id} message={msg} />
          ))}
          {isLoading && <TypingIndicator />}
          <div ref={bottomRef} />
        </div>
      )}
    </div>
  )
}
