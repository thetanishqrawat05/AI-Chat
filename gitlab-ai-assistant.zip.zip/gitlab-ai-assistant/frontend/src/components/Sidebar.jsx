import { useEffect, useState } from 'react'
import { Zap, ExternalLink, ArrowRight, Database, Clock } from 'lucide-react'
import axios from 'axios'

export default function Sidebar({ onSuggestionClick }) {
  const [suggestions, setSuggestions] = useState([])
  const [indexedTime] = useState(new Date().toLocaleString())

  useEffect(() => {
    axios.get('/api/chat/suggestions')
      .then(res => setSuggestions(res.data.suggestions || []))
      .catch(() => {})
  }, [])

  return (
    <aside
      className="hidden md:flex flex-col h-full overflow-y-auto"
      style={{
        width: 270,
        minWidth: 270,
        background: 'var(--bg-secondary)',
        borderRight: '1px solid var(--border)',
        flexShrink: 0,
      }}
    >
      {/* Suggestions */}
      <div className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <Zap size={14} style={{ color: 'var(--accent)' }} />
          <span
            style={{
              fontFamily: 'Syne, sans-serif',
              fontSize: '0.75rem',
              fontWeight: 600,
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color: 'var(--text-muted)',
            }}
          >
            Suggested Questions
          </span>
        </div>

        <div className="flex flex-col gap-2">
          {suggestions.map((suggestion, i) => (
            <button
              key={i}
              onClick={() => onSuggestionClick(suggestion)}
              className="flex items-start gap-2 w-full text-left rounded-lg p-2.5 group"
              style={{
                background: 'var(--bg-card)',
                border: '1px solid var(--border)',
                transition: 'all 200ms ease',
                cursor: 'pointer',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.background = 'var(--bg-hover)'
                e.currentTarget.style.borderColor = 'var(--border-light)'
              }}
              onMouseLeave={e => {
                e.currentTarget.style.background = 'var(--bg-card)'
                e.currentTarget.style.borderColor = 'var(--border)'
              }}
            >
              <span style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.5, flex: 1 }}>
                {suggestion}
              </span>
              <ArrowRight
                size={12}
                style={{ color: 'var(--text-muted)', marginTop: 3, flexShrink: 0, transition: 'color 200ms' }}
              />
            </button>
          ))}
        </div>
      </div>

      {/* Divider */}
      <div style={{ height: 1, background: 'var(--border)', margin: '0 16px' }} />

      {/* Data Sources */}
      <div className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <Database size={14} style={{ color: 'var(--accent)' }} />
          <span
            style={{
              fontFamily: 'Syne, sans-serif',
              fontSize: '0.75rem',
              fontWeight: 600,
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color: 'var(--text-muted)',
            }}
          >
            Data Sources
          </span>
        </div>

        <div className="flex flex-col gap-2">
          {[
            { label: 'handbook.gitlab.com', url: 'https://handbook.gitlab.com/' },
            { label: 'about.gitlab.com/direction', url: 'https://about.gitlab.com/direction/' },
          ].map(({ label, url }) => (
            <a
              key={url}
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between px-3 py-2 rounded-lg"
              style={{
                background: 'var(--bg-card)',
                border: '1px solid var(--border)',
                textDecoration: 'none',
                transition: 'all 200ms ease',
                fontSize: '0.8rem',
                color: 'var(--text-secondary)',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = 'var(--accent)'
                e.currentTarget.style.color = 'var(--accent)'
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = 'var(--border)'
                e.currentTarget.style.color = 'var(--text-secondary)'
              }}
            >
              <span>{label}</span>
              <ExternalLink size={11} style={{ opacity: 0.6 }} />
            </a>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="mt-auto p-4">
        <div
          className="flex items-center gap-2 px-3 py-2 rounded-lg"
          style={{
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
          }}
        >
          <Clock size={11} style={{ color: 'var(--text-muted)' }} />
          <div>
            <p style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>Knowledge indexed</p>
            <p style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', marginTop: 1 }}>{indexedTime}</p>
          </div>
        </div>
      </div>
    </aside>
  )
}
