import { useState, useRef, useEffect } from 'react'
import { Send, X } from 'lucide-react'

const MAX_CHARS = 1000

export default function InputBar({ onSend, isLoading, prefillText, onPrefillClear }) {
  const [text, setText] = useState('')
  const textareaRef = useRef(null)

  // Handle prefilled text from suggestions
  useEffect(() => {
    if (prefillText) {
      setText(prefillText)
      onPrefillClear?.()
      textareaRef.current?.focus()
    }
  }, [prefillText, onPrefillClear])

  // Auto-resize textarea
  useEffect(() => {
    const ta = textareaRef.current
    if (!ta) return
    ta.style.height = 'auto'
    ta.style.height = Math.min(ta.scrollHeight, 120) + 'px'
  }, [text])

  const handleSend = () => {
    const trimmed = text.trim()
    if (!trimmed || isLoading || trimmed.length > MAX_CHARS) return
    onSend(trimmed)
    setText('')
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const remaining = MAX_CHARS - text.length
  const showCounter = text.length > 500
  const isOverLimit = text.length > MAX_CHARS

  return (
    <div
      className="glass"
      style={{
        borderTop: '1px solid var(--border)',
        padding: '12px 16px',
        flexShrink: 0,
      }}
    >
      {/* Mobile suggestions row */}
      <div className="flex gap-2 overflow-x-auto pb-2 mb-2 md:hidden" style={{ scrollbarWidth: 'none' }}>
        {[
          "GitLab's core values?",
          "Remote work policy?",
          "Product direction 2025?",
        ].map((s, i) => (
          <button
            key={i}
            onClick={() => setText(s)}
            className="flex-shrink-0 px-2.5 py-1.5 rounded-full text-xs"
            style={{
              background: 'var(--bg-card)',
              border: '1px solid var(--border)',
              color: 'var(--text-muted)',
              cursor: 'pointer',
              whiteSpace: 'nowrap',
            }}
          >
            {s}
          </button>
        ))}
      </div>

      <div
        className="flex items-end gap-3 rounded-xl px-3 py-2.5 glow-border"
        style={{
          background: 'var(--bg-card)',
          border: '1px solid var(--border-light)',
          transition: 'all 200ms ease',
        }}
      >
        {/* Textarea */}
        <textarea
          ref={textareaRef}
          value={text}
          onChange={e => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={isLoading}
          placeholder="Ask anything about GitLab's handbook or product direction..."
          rows={1}
          className="flex-1 resize-none bg-transparent outline-none"
          style={{
            fontFamily: 'DM Sans, sans-serif',
            fontSize: '0.9rem',
            color: 'var(--text-primary)',
            lineHeight: 1.5,
            minHeight: 24,
            maxHeight: 120,
            border: 'none',
            scrollbarWidth: 'none',
          }}
        />

        {/* Right controls */}
        <div className="flex items-center gap-2 flex-shrink-0 pb-0.5">
          {/* Character counter */}
          {showCounter && (
            <span
              style={{
                fontSize: '0.72rem',
                color: isOverLimit ? 'var(--error)' : 'var(--text-muted)',
                fontVariantNumeric: 'tabular-nums',
              }}
            >
              {remaining}
            </span>
          )}

          {/* Clear button */}
          {text.length > 0 && !isLoading && (
            <button
              onClick={() => setText('')}
              style={{
                color: 'var(--text-muted)',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                padding: 2,
                display: 'flex',
                alignItems: 'center',
              }}
            >
              <X size={14} />
            </button>
          )}

          {/* Send button */}
          <button
            onClick={handleSend}
            disabled={!text.trim() || isLoading || isOverLimit}
            className="flex items-center justify-center rounded-lg"
            style={{
              width: 34,
              height: 34,
              background: !text.trim() || isLoading || isOverLimit
                ? 'var(--bg-hover)'
                : 'var(--accent)',
              border: 'none',
              cursor: !text.trim() || isLoading || isOverLimit ? 'not-allowed' : 'pointer',
              color: !text.trim() || isLoading || isOverLimit
                ? 'var(--text-muted)'
                : '#fff',
              flexShrink: 0,
              transition: 'all 200ms ease',
            }}
            onMouseEnter={e => {
              if (!e.currentTarget.disabled) {
                e.currentTarget.style.background = 'var(--accent-hover)'
              }
            }}
            onMouseLeave={e => {
              if (text.trim() && !isLoading && !isOverLimit) {
                e.currentTarget.style.background = 'var(--accent)'
              }
            }}
          >
            {isLoading ? (
              <div
                style={{
                  width: 14, height: 14,
                  border: '2px solid var(--text-muted)',
                  borderTopColor: 'transparent',
                  borderRadius: '50%',
                  animation: 'spin 0.8s linear infinite',
                }}
              />
            ) : (
              <Send size={15} />
            )}
          </button>
        </div>
      </div>

      <p style={{ fontSize: '0.68rem', color: 'var(--text-muted)', marginTop: 6, textAlign: 'center' }}>
        Press <kbd style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '0.65rem', padding: '1px 4px', background: 'var(--bg-hover)', borderRadius: 3, border: '1px solid var(--border)' }}>Enter</kbd> to send · <kbd style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '0.65rem', padding: '1px 4px', background: 'var(--bg-hover)', borderRadius: 3, border: '1px solid var(--border)' }}>Shift+Enter</kbd> for new line
      </p>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  )
}
