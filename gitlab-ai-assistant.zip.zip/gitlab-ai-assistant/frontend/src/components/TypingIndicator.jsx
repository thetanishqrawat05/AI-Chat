export default function TypingIndicator() {
  return (
    <div className="flex items-start gap-3 message-enter px-4 py-2">
      {/* Avatar */}
      <div
        className="flex items-center justify-center rounded-full flex-shrink-0"
        style={{
          width: 32,
          height: 32,
          background: 'var(--accent-glow)',
          border: '1px solid var(--accent)',
        }}
      >
        <svg width="18" height="18" viewBox="0 0 60 60" fill="none">
          <path d="M30 52L8 22l5-14 7 14h20l7-14 5 14L30 52z" fill="#e5673a" opacity="0.95"/>
          <path d="M30 52L15 22h30L30 52z" fill="#c8531f"/>
          <path d="M8 22L13 8l7 14H8z" fill="#f0774a"/>
          <path d="M52 22L47 8l-7 14h12z" fill="#f0774a"/>
        </svg>
      </div>

      {/* Bubble */}
      <div
        className="rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-2"
        style={{
          background: 'var(--ai-bubble)',
          border: '1px solid var(--border)',
          minWidth: 100,
        }}
      >
        <div className="flex items-center gap-1.5">
          <div className="typing-dot" />
          <div className="typing-dot" />
          <div className="typing-dot" />
        </div>
        <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginLeft: 4 }}>
          GitLab AI is thinking...
        </span>
      </div>
    </div>
  )
}
