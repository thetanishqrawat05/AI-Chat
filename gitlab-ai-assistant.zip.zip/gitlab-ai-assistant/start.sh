#!/bin/bash
set -e

echo "==> Installing backend dependencies..."
pip install -r backend/requirements.txt -q

echo "==> Installing frontend dependencies..."
cd frontend
npm install --silent

echo "==> Building frontend..."
npm run build
cd ..

echo "==> Starting GitLab AI Assistant on port 8000..."
cd backend
uvicorn main:app --host 0.0.0.0 --port 8000
