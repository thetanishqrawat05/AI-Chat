import os
from typing import List, Dict, Any
import chromadb
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from embeddings import query_vectorstore

SYSTEM_PROMPT = (
    "You are the GitLab AI Assistant — an expert on GitLab's internal handbook, values, "
    "processes, and product direction. You answer questions clearly, accurately, and concisely "
    "based only on the provided context. If the answer is not in the context, say: "
    "'I don't have specific information about that in the GitLab Handbook. Please check "
    "handbook.gitlab.com directly.' Always be helpful, professional, and aligned with GitLab's "
    "values of transparency and collaboration."
)


def get_llm() -> ChatGoogleGenerativeAI:
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise ValueError("GEMINI_API_KEY environment variable is not set.")
    return ChatGoogleGenerativeAI(
        model="gemini-1.5-flash",
        google_api_key=api_key,
        temperature=0.3,
    )


def build_context_string(chunks: List[Dict]) -> str:
    parts = []
    for i, chunk in enumerate(chunks, 1):
        parts.append(f"[Source {i}: {chunk['source']}]\n{chunk['text']}")
    return "\n\n---\n\n".join(parts)


def get_rag_response(
    query: str,
    collection: chromadb.Collection,
    chat_history: List[Dict[str, str]] = [],
) -> Dict[str, Any]:
    try:
        # Retrieve relevant context
        chunks = query_vectorstore(collection, query, n_results=5)
        context = build_context_string(chunks)

        # Build sources list
        seen_sources = set()
        sources = []
        for chunk in chunks:
            src = chunk["source"]
            if src not in seen_sources:
                seen_sources.add(src)
                sources.append({
                    "url": src,
                    "snippet": chunk["text"][:150],
                })

        # Build message list
        messages = [SystemMessage(content=SYSTEM_PROMPT)]

        # Add last 6 history messages
        recent_history = chat_history[-6:] if len(chat_history) > 6 else chat_history
        for msg in recent_history:
            if msg["role"] == "user":
                messages.append(HumanMessage(content=msg["content"]))
            elif msg["role"] == "assistant":
                messages.append(AIMessage(content=msg["content"]))

        # Add current query with context
        user_message = (
            f"Context from GitLab Handbook and Direction pages:\n\n{context}\n\n"
            f"---\n\nQuestion: {query}"
        )
        messages.append(HumanMessage(content=user_message))

        # Call Gemini
        llm = get_llm()
        response = llm.invoke(messages)
        answer = response.content

        # Approximate token count
        tokens_used = len(user_message.split()) + len(answer.split())

        return {
            "answer": answer,
            "sources": sources,
            "tokens_used": tokens_used,
        }

    except ValueError as e:
        return {
            "answer": f"⚠️ Configuration error: {str(e)}. Please ensure GEMINI_API_KEY is set in Replit Secrets.",
            "sources": [],
            "tokens_used": 0,
        }
    except Exception as e:
        print(f"[RAG] Error: {e}")
        return {
            "answer": (
                "I encountered an error while processing your request. "
                "Please try again in a moment. If the problem persists, "
                "check that the API key is configured correctly."
            ),
            "sources": [],
            "tokens_used": 0,
        }
