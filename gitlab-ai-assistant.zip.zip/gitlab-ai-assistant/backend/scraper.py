import httpx
from bs4 import BeautifulSoup
from typing import List, Dict

GITLAB_URLS = [
    "https://handbook.gitlab.com/handbook/",
    "https://handbook.gitlab.com/handbook/values/",
    "https://handbook.gitlab.com/handbook/communication/",
    "https://handbook.gitlab.com/handbook/engineering/",
    "https://handbook.gitlab.com/handbook/product/",
    "https://handbook.gitlab.com/handbook/people-group/",
    "https://about.gitlab.com/direction/",
    "https://about.gitlab.com/direction/dev/",
    "https://about.gitlab.com/direction/ops/",
    "https://about.gitlab.com/direction/govern/",
]

CHUNK_SIZE = 800
CHUNK_OVERLAP = 150


def chunk_text(text: str, url: str) -> List[Dict]:
    chunks = []
    start = 0
    i = 0
    while start < len(text):
        end = start + CHUNK_SIZE
        chunk = text[start:end]
        if chunk.strip():
            chunks.append({
                "text": chunk,
                "source": url,
                "chunk_id": f"{url}_{i}"
            })
        start += CHUNK_SIZE - CHUNK_OVERLAP
        i += 1
    return chunks


def scrape_url(url: str) -> List[Dict]:
    headers = {"User-Agent": "Mozilla/5.0 (compatible; GitLabAIAssistant/1.0)"}
    try:
        print(f"[Scraper] Fetching: {url}")
        with httpx.Client(timeout=30, follow_redirects=True) as client:
            response = client.get(url, headers=headers)
            response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")

        # Remove unwanted tags
        for tag in soup(["script", "style", "nav", "footer", "header"]):
            tag.decompose()

        # Extract main content
        content = soup.find("main") or soup.find("article") or soup.find("body")
        if not content:
            print(f"[Scraper] No content found for {url}")
            return []

        text = content.get_text(separator=" ", strip=True)
        # Clean up excessive whitespace
        import re
        text = re.sub(r"\s+", " ", text).strip()

        chunks = chunk_text(text, url)
        print(f"[Scraper] Got {len(chunks)} chunks from {url}")
        return chunks

    except Exception as e:
        print(f"[Scraper] Error scraping {url}: {e}")
        return []


def scrape_gitlab_sources() -> List[Dict]:
    all_chunks = []
    for url in GITLAB_URLS:
        chunks = scrape_url(url)
        all_chunks.extend(chunks)
    print(f"[Scraper] Total chunks collected: {len(all_chunks)}")
    return all_chunks
