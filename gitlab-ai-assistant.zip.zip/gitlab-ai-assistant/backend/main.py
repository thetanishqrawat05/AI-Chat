import os
import threading
from contextlib import asynccontextmanager
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

load_dotenv()

# Global state
vectorstore_ready: bool = False
collection = None
indexing_error: str = None


def run_indexing():
    global vectorstore_ready, collection, indexing_error
    try:
        print("[Main] Starting vector store initialization...")
        from embeddings import initialize_vectorstore
        collection = initialize_vectorstore()
        vectorstore_ready = True
        print("[Main] Vector store ready!")
    except Exception as e:
        indexing_error = str(e)
        print(f"[Main] Indexing failed: {e}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Start indexing in background thread
    thread = threading.Thread(target=run_indexing, daemon=True)
    thread.start()
    yield


app = FastAPI(
    title="GitLab AI Assistant API",
    description="RAG-powered chatbot for GitLab Handbook and Direction pages.",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
from routes.chat import router as chat_router
from routes.status import router as status_router

app.include_router(chat_router, prefix="/api")
app.include_router(status_router, prefix="/api")


@app.get("/api")
async def api_root():
    return {"message": "GitLab AI Assistant API is running"}


# Serve frontend static files in production
FRONTEND_DIST = Path(__file__).parent.parent / "frontend" / "dist"

if FRONTEND_DIST.exists():
    app.mount("/assets", StaticFiles(directory=str(FRONTEND_DIST / "assets")), name="assets")

    @app.get("/")
    async def serve_frontend():
        return FileResponse(str(FRONTEND_DIST / "index.html"))

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        # Don't catch API routes
        if full_path.startswith("api/"):
            from fastapi import HTTPException
            raise HTTPException(status_code=404)
        file_path = FRONTEND_DIST / full_path
        if file_path.exists() and file_path.is_file():
            return FileResponse(str(file_path))
        return FileResponse(str(FRONTEND_DIST / "index.html"))
else:
    @app.get("/")
    async def root():
        return {"message": "GitLab AI Assistant is running. Frontend not built yet."}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
