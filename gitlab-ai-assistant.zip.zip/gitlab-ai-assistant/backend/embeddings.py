import os
from typing import List, Dict, Optional
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings
from scraper import scrape_gitlab_sources

CHROMA_PATH = "./chroma_db"
COLLECTION_NAME = "gitlab_knowledge"
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

_embedder: Optional[SentenceTransformer] = None


def get_embedder() -> SentenceTransformer:
    global _embedder
    if _embedder is None:
        print("[Embeddings] Loading sentence transformer model...")
        _embedder = SentenceTransformer(EMBEDDING_MODEL)
        print("[Embeddings] Model loaded.")
    return _embedder


def get_chroma_client() -> chromadb.PersistentClient:
    return chromadb.PersistentClient(path=CHROMA_PATH)


def embed_and_store(chunks: List[Dict], collection: chromadb.Collection) -> None:
    embedder = get_embedder()
    batch_size = 50
    total = len(chunks)

    for batch_start in range(0, total, batch_size):
        batch = chunks[batch_start: batch_start + batch_size]
        texts = [c["text"] for c in batch]
        ids = [c["chunk_id"] for c in batch]
        metadatas = [{"source": c["source"], "chunk_id": c["chunk_id"]} for c in batch]

        embeddings = embedder.encode(texts, show_progress_bar=False).tolist()

        collection.upsert(
            ids=ids,
            documents=texts,
            embeddings=embeddings,
            metadatas=metadatas,
        )
        print(f"[Embeddings] Stored {min(batch_start + batch_size, total)}/{total} chunks")


def initialize_vectorstore() -> chromadb.Collection:
    client = get_chroma_client()

    # Check if collection already exists with data
    try:
        collection = client.get_collection(COLLECTION_NAME)
        count = collection.count()
        if count > 0:
            print(f"[Embeddings] Loaded existing collection with {count} documents.")
            return collection
        else:
            print("[Embeddings] Collection empty, re-indexing...")
    except Exception:
        print("[Embeddings] No existing collection found, creating new one.")

    # Create or recreate collection
    try:
        client.delete_collection(COLLECTION_NAME)
    except Exception:
        pass

    collection = client.create_collection(
        name=COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"},
    )

    print("[Embeddings] Scraping GitLab sources...")
    chunks = scrape_gitlab_sources()

    if not chunks:
        print("[Embeddings] WARNING: No chunks scraped. Check network connectivity.")
    else:
        embed_and_store(chunks, collection)
        print(f"[Embeddings] Indexing complete. {len(chunks)} chunks stored.")

    return collection


def query_vectorstore(collection: chromadb.Collection, query: str, n_results: int = 5) -> List[Dict]:
    embedder = get_embedder()
    query_embedding = embedder.encode([query]).tolist()[0]

    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=n_results,
        include=["documents", "metadatas", "distances"],
    )

    output = []
    if results and results["documents"] and results["documents"][0]:
        for doc, meta, dist in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        ):
            output.append({
                "text": doc,
                "source": meta.get("source", ""),
                "distance": dist,
            })
    return output
