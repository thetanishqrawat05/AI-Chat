from fastapi import APIRouter

router = APIRouter()


@router.get("/status")
async def get_status():
    from main import vectorstore_ready, collection, indexing_error

    if indexing_error:
        return {
            "status": "error",
            "documents_indexed": 0,
            "model": "gemini-1.5-flash",
            "message": f"Indexing failed: {indexing_error}",
        }

    if not vectorstore_ready:
        return {
            "status": "indexing",
            "documents_indexed": 0,
            "model": "gemini-1.5-flash",
            "message": "Indexing GitLab knowledge base. Please wait ~30 seconds...",
        }

    doc_count = 0
    try:
        if collection:
            doc_count = collection.count()
    except Exception:
        pass

    return {
        "status": "ready",
        "documents_indexed": doc_count,
        "model": "gemini-1.5-flash",
        "message": f"Ready. {doc_count} document chunks indexed from GitLab Handbook and Direction pages.",
    }
