import uuid
from typing import List, Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, validator

router = APIRouter()


class HistoryMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = None
    history: Optional[List[HistoryMessage]] = []

    @validator("message")
    def message_must_be_valid(cls, v):
        if not v or not v.strip():
            raise ValueError("Message cannot be empty.")
        if len(v) > 1000:
            raise ValueError("Message cannot exceed 1000 characters.")
        return v.strip()


class ChatResponse(BaseModel):
    answer: str
    sources: list
    conversation_id: str
    tokens_used: int


@router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    # Import here to avoid circular issues with global state
    from main import vectorstore_ready, collection

    if not vectorstore_ready:
        raise HTTPException(
            status_code=503,
            detail="Still indexing GitLab knowledge base. Please wait about 30 seconds and try again.",
        )

    if collection is None:
        raise HTTPException(
            status_code=503,
            detail="Vector store not initialized. Please restart the application.",
        )

    conversation_id = request.conversation_id or str(uuid.uuid4())
    history = [{"role": m.role, "content": m.content} for m in (request.history or [])]
    history = history[-6:]

    try:
        from rag_pipeline import get_rag_response
        result = get_rag_response(
            query=request.message,
            collection=collection,
            chat_history=history,
        )
        return ChatResponse(
            answer=result["answer"],
            sources=result["sources"],
            conversation_id=conversation_id,
            tokens_used=result["tokens_used"],
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/chat/suggestions")
async def get_suggestions():
    return {
        "suggestions": [
            "What are GitLab's core values?",
            "How does GitLab handle remote work?",
            "What is GitLab's product direction for 2025?",
            "How does GitLab approach engineering culture?",
            "What is GitLab's approach to transparency?",
            "How does GitLab handle performance reviews?",
        ]
    }
