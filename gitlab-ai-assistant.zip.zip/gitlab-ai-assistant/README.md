# GitLab AI Assistant 🦊

A production-grade RAG (Retrieval-Augmented Generation) chatbot that helps GitLab employees query information from GitLab's public Handbook and Direction pages — powered by Google Gemini and ChromaDB.

---

## Features

- 🔍 **RAG Pipeline** — Retrieves relevant context from 10 GitLab pages before answering
- 🧠 **Gemini 1.5 Flash** — Fast, accurate AI responses grounded in GitLab's documentation
- 💾 **Persistent Vector Store** — ChromaDB indexes content once; restarts are instant
- 💬 **Multi-turn Conversations** — Maintains session history for contextual follow-up
- 📎 **Source Attribution** — Every answer links back to its source pages
- 🌙 **Premium Dark UI** — Polished interface inspired by Linear.app

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    GitLab AI Assistant                   │
├─────────────────┬───────────────────────────────────────┤
│   React Frontend│           FastAPI Backend             │
│   (Vite + TW)  │                                        │
│                 │  ┌──────────┐    ┌─────────────────┐  │
│  ChatWindow     │  │ /api/chat│───▶│  RAG Pipeline   │  │
│  MessageBubble  │  └──────────┘    └────────┬────────┘  │
│  Sidebar        │                           │           │
│  InputBar       │  ┌──────────┐    ┌────────▼────────┐  │
│                 │  │ChromaDB  │◀───│sentence-transf. │  │
│                 │  │(persisted│    │embeddings       │  │
│                 │  └──────────┘    └─────────────────┘  │
│                 │                           │           │
│                 │                  ┌────────▼────────┐  │
│                 │                  │  Gemini 1.5     │  │
│                 │                  │  Flash API      │  │
│                 │                  └─────────────────┘  │
└─────────────────┴───────────────────────────────────────┘
```

---

## Setup

### On Replit

1. **Fork or import** this repo into Replit
2. Go to **Secrets** (🔒 icon in the sidebar)
3. Add secret: `GEMINI_API_KEY` = your key from [Google AI Studio](https://aistudio.google.com/app/apikey)
4. Click **Run** — the app will install dependencies, build the frontend, and start

### Local Development

```bash
# 1. Clone the repo
git clone <repo-url>
cd gitlab-ai-assistant

# 2. Set up backend
cd backend
pip install -r requirements.txt
cp ../.env.example ../.env
# Edit .env and add your GEMINI_API_KEY

# 3. Start backend
uvicorn main:app --host 0.0.0.0 --port 8000 --reload

# 4. In another terminal, start frontend
cd frontend
npm install
npm run dev
# Visit http://localhost:5173
```

### Getting a Gemini API Key

1. Go to [Google AI Studio](https://aistudio.google.com/app/apikey)
2. Sign in with your Google account
3. Click **Create API key**
4. Copy it and set it as `GEMINI_API_KEY`

---

## How the RAG Pipeline Works

```
User Question
      │
      ▼
Embed question with sentence-transformers (all-MiniLM-L6-v2)
      │
      ▼
Query ChromaDB → Top 5 most relevant chunks
      │
      ▼
Build prompt: System + Chat History + Context + Question
      │
      ▼
Send to Gemini 1.5 Flash
      │
      ▼
Return answer + source URLs to frontend
```

**On first startup:**
- The app scrapes 10 GitLab Handbook and Direction pages
- Text is chunked (800 chars, 150 overlap) and embedded
- Embeddings are stored in ChromaDB on disk (`./chroma_db/`)
- Subsequent restarts skip scraping entirely

---

## Data Sources

| Page | URL |
|------|-----|
| GitLab Handbook | handbook.gitlab.com/handbook/ |
| GitLab Values | handbook.gitlab.com/handbook/values/ |
| Communication | handbook.gitlab.com/handbook/communication/ |
| Engineering | handbook.gitlab.com/handbook/engineering/ |
| Product | handbook.gitlab.com/handbook/product/ |
| People Group | handbook.gitlab.com/handbook/people-group/ |
| Direction | about.gitlab.com/direction/ |
| Dev Direction | about.gitlab.com/direction/dev/ |
| Ops Direction | about.gitlab.com/direction/ops/ |
| Govern Direction | about.gitlab.com/direction/govern/ |

---

## Limitations & Future Improvements

- **Coverage**: Only 10 pages are indexed; the full handbook is much larger
- **Staleness**: Data is indexed once at startup; add a cron job to refresh weekly
- **Embeddings model**: `all-MiniLM-L6-v2` is fast but not the most accurate — try `bge-large-en`
- **No auth**: Anyone with the URL can use the chatbot
- **Streaming**: Responses are returned all at once; streaming would improve UX
- **Reranking**: Add a cross-encoder reranker after vector retrieval for better precision
