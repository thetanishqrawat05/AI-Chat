#!/bin/bash
set -e

echo "═══════════════════════════════════════════"
echo "  GitLab AI Assistant v2 - Starting..."
echo "═══════════════════════════════════════════"

echo ""
echo "[1/5] Installing Python dependencies..."
pip install -r backend/requirements.txt -q

echo ""
echo "[2/5] Installing Node dependencies..."
npm install --silent

echo ""
echo "[3/5] Building frontend..."
npm run build

echo ""
echo "[4/5] Initializing database..."
cd backend && python -c "import asyncio; from database import init_db; asyncio.run(init_db())" && cd ..

echo ""
echo "[5/5] Starting server..."
echo ""
echo "═══════════════════════════════════════════"
echo "  Server starting on http://localhost:8000"
echo "  Default admin login:"
echo "    Email: admin@gitlab.com"
echo "    Password: Admin@12345"
echo "═══════════════════════════════════════════"
echo ""

cd backend && uvicorn main:app --host 0.0.0.0 --port 8000
