import aiosqlite
import json
from datetime import datetime
from pathlib import Path
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

DB_PATH = Path(__file__).parent / "gitlab_ai.db"

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                username TEXT UNIQUE NOT NULL,
                hashed_password TEXT NOT NULL,
                role TEXT DEFAULT 'user',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT TRUE
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                title TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                conversation_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                sources TEXT,
                tokens_used INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (conversation_id) REFERENCES conversations(id)
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message_id TEXT NOT NULL,
                user_id INTEGER NOT NULL,
                rating INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(message_id, user_id)
            )
        """)

        cursor = await db.execute("SELECT COUNT(*) FROM users WHERE email = 'admin@gitlab.com'")
        count = await cursor.fetchone()

        if count[0] == 0:
            hashed_password = pwd_context.hash("Admin@12345")
            await db.execute(
                "INSERT INTO users (email, username, hashed_password, role) VALUES (?, ?, ?, ?)",
                ("admin@gitlab.com", "admin", hashed_password, "admin")
            )

        await db.commit()

async def get_user_by_email(email: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM users WHERE email = ?", (email,))
        return await cursor.fetchone()

async def get_user_by_username(username: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM users WHERE username = ?", (username,))
        return await cursor.fetchone()

async def get_user_by_id(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        return await cursor.fetchone()

async def create_user(email: str, username: str, hashed_password: str):
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "INSERT INTO users (email, username, hashed_password) VALUES (?, ?, ?)",
            (email, username, hashed_password)
        )
        await db.commit()
        return cursor.lastrowid

async def create_conversation(conv_id: str, user_id: int, title: str = None):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO conversations (id, user_id, title) VALUES (?, ?, ?)",
            (conv_id, user_id, title)
        )
        await db.commit()

async def update_conversation_title(conv_id: str, title: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE conversations SET title = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            (title, conv_id)
        )
        await db.commit()

async def get_user_conversations(user_id: int, limit: int = 20):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("""
            SELECT c.id, c.title, c.updated_at,
                   COUNT(m.id) as message_count
            FROM conversations c
            LEFT JOIN messages m ON c.id = m.conversation_id
            WHERE c.user_id = ?
            GROUP BY c.id
            ORDER BY c.updated_at DESC
            LIMIT ?
        """, (user_id, limit))
        return await cursor.fetchall()

async def get_conversation_messages(conv_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("""
            SELECT id, role, content, sources, tokens_used, created_at
            FROM messages
            WHERE conversation_id = ?
            ORDER BY created_at ASC
        """, (conv_id,))
        return await cursor.fetchall()

async def delete_conversation(conv_id: str, user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM messages WHERE conversation_id = ?", (conv_id,))
        await db.execute("DELETE FROM conversations WHERE id = ? AND user_id = ?", (conv_id, user_id))
        await db.commit()

async def create_message(msg_id: str, conv_id: str, role: str, content: str, sources: str = None, tokens: int = 0):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO messages (id, conversation_id, role, content, sources, tokens_used) VALUES (?, ?, ?, ?, ?, ?)",
            (msg_id, conv_id, role, content, sources, tokens)
        )
        await db.execute(
            "UPDATE conversations SET updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            (conv_id,)
        )
        await db.commit()

async def upsert_feedback(message_id: str, user_id: int, rating: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT INTO feedback (message_id, user_id, rating)
            VALUES (?, ?, ?)
            ON CONFLICT(message_id, user_id)
            DO UPDATE SET rating = ?, created_at = CURRENT_TIMESTAMP
        """, (message_id, user_id, rating, rating))
        await db.commit()

async def get_feedback_stats():
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("""
            SELECT
                SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as positive,
                SUM(CASE WHEN rating = -1 THEN 1 ELSE 0 END) as negative
            FROM feedback
        """)
        row = await cursor.fetchone()

        cursor = await db.execute("""
            SELECT m.content, f.rating, f.created_at
            FROM feedback f
            JOIN messages m ON f.message_id = m.id
            ORDER BY f.created_at DESC
            LIMIT 10
        """)
        recent = await cursor.fetchall()

        return {
            "total_positive": row[0] or 0,
            "total_negative": row[1] or 0,
            "recent_feedback": [
                {"content": r[0][:100], "rating": r[1], "created_at": r[2]}
                for r in recent
            ]
        }

async def get_admin_stats():
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT COUNT(*) FROM users")
        total_users = (await cursor.fetchone())[0]

        cursor = await db.execute("SELECT COUNT(*) FROM conversations")
        total_conversations = (await cursor.fetchone())[0]

        cursor = await db.execute("SELECT COUNT(*) FROM messages")
        total_messages = (await cursor.fetchone())[0]

        cursor = await db.execute("""
            SELECT content, COUNT(*) as cnt
            FROM messages
            WHERE role = 'user' AND created_at >= datetime('now', '-7 days')
            GROUP BY content
            ORDER BY cnt DESC
            LIMIT 5
        """)
        top_questions = [row[0][:100] for row in await cursor.fetchall()]

        return {
            "total_users": total_users,
            "total_conversations": total_conversations,
            "total_messages": total_messages,
            "top_questions": top_questions
        }
