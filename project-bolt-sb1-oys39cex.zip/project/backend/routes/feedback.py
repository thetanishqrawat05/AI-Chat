from fastapi import APIRouter, Depends
from pydantic import BaseModel
from backend.auth import get_current_user, require_admin
from backend.database import upsert_feedback, get_feedback_stats

router = APIRouter(prefix="/api/feedback", tags=["feedback"])

class FeedbackRequest(BaseModel):
    message_id: str
    rating: int

@router.post("")
async def submit_feedback(req: FeedbackRequest, user = Depends(get_current_user)):
    if req.rating not in [1, -1]:
        return {"success": False, "error": "Rating must be 1 or -1"}

    await upsert_feedback(req.message_id, user["id"], req.rating)
    return {"success": True}

@router.get("/stats")
async def get_stats(user = Depends(require_admin)):
    stats = await get_feedback_stats()
    return stats
