from fastapi import APIRouter, Depends, BackgroundTasks
from backend.auth import require_admin
from backend.database import get_admin_stats, get_feedback_stats
from backend.scraper import scrape_and_embed
import asyncio

router = APIRouter(prefix="/api/admin", tags=["admin"])

reindex_task_running = False

async def run_reindex():
    global reindex_task_running
    try:
        reindex_task_running = True
        await scrape_and_embed()
    finally:
        reindex_task_running = False

@router.get("/stats")
async def get_stats(user = Depends(require_admin)):
    admin_stats = await get_admin_stats()
    feedback_stats = await get_feedback_stats()

    total_feedback = feedback_stats["total_positive"] + feedback_stats["total_negative"]
    positive_rate = (
        feedback_stats["total_positive"] / total_feedback
        if total_feedback > 0
        else 0.0
    )

    from backend.embeddings import get_collection
    collection = await get_collection()
    doc_count = collection.count() if collection else 0

    return {
        "total_users": admin_stats["total_users"],
        "total_conversations": admin_stats["total_conversations"],
        "total_messages": admin_stats["total_messages"],
        "documents_indexed": doc_count,
        "positive_feedback_rate": round(positive_rate, 2),
        "top_questions": admin_stats["top_questions"]
    }

@router.post("/reindex")
async def reindex(background_tasks: BackgroundTasks, user = Depends(require_admin)):
    if reindex_task_running:
        return {"status": "reindexing_already_running"}

    background_tasks.add_task(run_reindex)
    return {"status": "reindexing_started"}
