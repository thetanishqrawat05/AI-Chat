from fastapi import APIRouter, Depends, HTTPException, status
from backend.auth import get_current_user
from backend.database import get_user_conversations, get_conversation_messages, delete_conversation

router = APIRouter(prefix="/api/history", tags=["history"])

@router.get("/conversations")
async def get_conversations(user = Depends(get_current_user)):
    conversations = await get_user_conversations(user["id"])
    return {
        "conversations": [
            {
                "id": conv["id"],
                "title": conv["title"] or "New Conversation",
                "updated_at": conv["updated_at"],
                "message_count": conv["message_count"]
            }
            for conv in conversations
        ]
    }

@router.get("/conversations/{conv_id}/messages")
async def get_messages(conv_id: str, user = Depends(get_current_user)):
    messages = await get_conversation_messages(conv_id)

    if messages:
        first_msg = messages[0]
        conv_cursor = await get_user_conversations(user["id"])
        conv_ids = [c["id"] for c in conv_cursor]
        if conv_id not in conv_ids:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not authorized to access this conversation"
            )

    import json
    return {
        "messages": [
            {
                "id": msg["id"],
                "role": msg["role"],
                "content": msg["content"],
                "sources": json.loads(msg["sources"]) if msg["sources"] else None,
                "tokens": msg["tokens_used"],
                "created_at": msg["created_at"]
            }
            for msg in messages
        ]
    }

@router.delete("/conversations/{conv_id}")
async def delete_conv(conv_id: str, user = Depends(get_current_user)):
    await delete_conversation(conv_id, user["id"])
    return {"message": "Conversation deleted successfully"}
