import json
import uuid
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Optional
from backend.auth import get_current_user
from backend.database import create_conversation, create_message, update_conversation_title
from backend.embeddings import get_collection
from backend.rag_pipeline import stream_rag_response
import google.generativeai as genai
import os

router = APIRouter(prefix="/api/chat", tags=["chat"])

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

class ChatMessage(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = None
    history: List[ChatMessage] = []

class FollowUpRequest(BaseModel):
    question: str
    answer: str

@router.post("/stream")
async def chat_stream(req: ChatRequest, user = Depends(get_current_user)):
    try:
        collection = await get_collection()

        conv_id = req.conversation_id or str(uuid.uuid4())
        is_new_conversation = req.conversation_id is None

        if is_new_conversation:
            await create_conversation(conv_id, user["id"])

        async def generate():
            try:
                full_response = ""
                sources = []
                token_count = 0

                async for chunk in stream_rag_response(
                    req.message,
                    collection,
                    req.history[-6:] if req.history else [],
                    user["id"]
                ):
                    if isinstance(chunk, dict):
                        sources = chunk.get("sources", [])
                        token_count = chunk.get("tokens", 0)
                        yield f"data: {json.dumps({'done': True, 'sources': sources, 'conversation_id': conv_id})}\n\n"
                    else:
                        full_response += chunk
                        yield f"data: {json.dumps({'token': chunk})}\n\n"

                user_msg_id = str(uuid.uuid4())
                await create_message(user_msg_id, conv_id, "user", req.message)

                assistant_msg_id = str(uuid.uuid4())
                sources_json = json.dumps(sources) if sources else None
                await create_message(
                    assistant_msg_id,
                    conv_id,
                    "assistant",
                    full_response,
                    sources_json,
                    token_count
                )

                if is_new_conversation and req.message:
                    title = req.message[:50] + "..." if len(req.message) > 50 else req.message
                    await update_conversation_title(conv_id, title)

            except Exception as e:
                error_msg = f"Error during streaming: {str(e)}"
                yield f"data: {json.dumps({'error': error_msg})}\n\n"

        return StreamingResponse(
            generate(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
            }
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/followups")
async def generate_followups(req: FollowUpRequest, user = Depends(get_current_user)):
    try:
        model = genai.GenerativeModel('gemini-1.5-flash')

        prompt = f"""Based on this Q&A exchange, generate exactly 3 short follow-up questions a user might ask next.
Return ONLY a JSON array of 3 strings, no preamble, no explanation.

Question: {req.question}
Answer: {req.answer[:500]}

Format: ["question 1", "question 2", "question 3"]"""

        response = model.generate_content(prompt)
        text = response.text.strip()

        if text.startswith("```"):
            text = text.split("```")[1]
            if text.startswith("json"):
                text = text[4:]
            text = text.strip()

        suggestions = json.loads(text)

        if isinstance(suggestions, list) and len(suggestions) == 3:
            return {"suggestions": suggestions}
        else:
            return {"suggestions": [
                "Can you explain that in more detail?",
                "What are the key takeaways?",
                "How does this relate to other GitLab features?"
            ]}

    except Exception as e:
        return {"suggestions": [
            "Tell me more about this topic",
            "What are the best practices here?",
            "How can I learn more?"
        ]}

@router.get("/suggestions")
async def get_suggestions():
    return {
        "suggestions": [
            "What are GitLab's core values?",
            "How does GitLab handle remote work?",
            "What is GitLab's product direction?",
            "Tell me about GitLab's engineering practices"
        ]
    }
