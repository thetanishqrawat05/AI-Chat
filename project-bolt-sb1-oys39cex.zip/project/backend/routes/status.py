from fastapi import APIRouter
import os

router = APIRouter(prefix="/api", tags=["status"])

@router.get("/status")
async def get_status():
    has_api_key = bool(os.getenv("GEMINI_API_KEY"))

    from backend.embeddings import get_collection
    try:
        collection = await get_collection()
        doc_count = collection.count() if collection else 0
        vector_db_status = "ready"
    except Exception as e:
        doc_count = 0
        vector_db_status = "error"

    return {
        "status": "online" if has_api_key else "needs_config",
        "vector_db": vector_db_status,
        "documents": doc_count,
        "message": "Ready" if has_api_key else "GEMINI_API_KEY required"
    }
