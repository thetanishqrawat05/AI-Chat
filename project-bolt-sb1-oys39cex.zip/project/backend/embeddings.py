import chromadb
from chromadb.config import Settings
from pathlib import Path

_embedder = None
_collection = None
_chroma_client = None

def get_embedder():
    global _embedder
    if _embedder is None:
        from sentence_transformers import SentenceTransformer
        _embedder = SentenceTransformer('all-MiniLM-L6-v2')
    return _embedder

def get_chroma_client():
    global _chroma_client
    if _chroma_client is None:
        persist_dir = Path(__file__).parent / "chroma_db"
        persist_dir.mkdir(exist_ok=True)

        _chroma_client = chromadb.Client(Settings(
            persist_directory=str(persist_dir),
            anonymized_telemetry=False
        ))
    return _chroma_client

async def get_collection():
    global _collection
    if _collection is None:
        client = get_chroma_client()
        try:
            _collection = client.get_collection("gitlab_docs")
        except:
            _collection = client.create_collection(
                name="gitlab_docs",
                metadata={"description": "GitLab handbook and direction documents"}
            )
    return _collection

def query_documents(query: str, n_results: int = 5):
    embedder = get_embedder()
    query_embedding = embedder.encode([query]).tolist()

    import asyncio
    collection = asyncio.run(get_collection())

    results = collection.query(
        query_embeddings=query_embedding,
        n_results=n_results
    )

    return results
