import httpx
from bs4 import BeautifulSoup
from typing import List, Dict
import asyncio

GITLAB_URLS = [
    "https://handbook.gitlab.com/handbook/",
    "https://handbook.gitlab.com/handbook/values/",
    "https://handbook.gitlab.com/handbook/communication/",
    "https://handbook.gitlab.com/handbook/engineering/",
    "https://handbook.gitlab.com/handbook/product/",
    "https://handbook.gitlab.com/handbook/people-group/",
    "https://handbook.gitlab.com/handbook/finance/",
    "https://handbook.gitlab.com/handbook/legal/",
    "https://handbook.gitlab.com/handbook/marketing/",
    "https://handbook.gitlab.com/handbook/sales/",
    "https://about.gitlab.com/direction/",
    "https://about.gitlab.com/direction/dev/",
    "https://about.gitlab.com/direction/ops/",
    "https://about.gitlab.com/direction/govern/",
    "https://about.gitlab.com/direction/monitor/",
    "https://about.gitlab.com/direction/secure/",
    "https://about.gitlab.com/direction/plan/",
    "https://about.gitlab.com/direction/create/",
    "https://about.gitlab.com/direction/verify/",
    "https://about.gitlab.com/direction/package/",
]

async def scrape_url(url: str) -> Dict[str, str]:
    try:
        async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
            response = await client.get(url)
            response.raise_for_status()

        soup = BeautifulSoup(response.text, 'html.parser')

        for tag in soup(['script', 'style', 'nav', 'footer', 'header']):
            tag.decompose()

        content = soup.get_text(separator='\n', strip=True)

        lines = [line.strip() for line in content.split('\n') if line.strip()]
        content = '\n'.join(lines)

        return {
            "url": url,
            "content": content[:50000]
        }

    except Exception as e:
        print(f"Error scraping {url}: {str(e)}")
        return {
            "url": url,
            "content": f"Error: Could not fetch content from {url}"
        }

async def scrape_all_urls() -> List[Dict[str, str]]:
    tasks = [scrape_url(url) for url in GITLAB_URLS]
    results = await asyncio.gather(*tasks)
    return results

def chunk_text(text: str, chunk_size: int = 1000, overlap: int = 200) -> List[str]:
    chunks = []
    start = 0
    text_length = len(text)

    while start < text_length:
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk)
        start = end - overlap

    return chunks

async def scrape_and_embed():
    from backend.embeddings import get_embedder, get_collection

    print("Starting scraping process...")
    documents = await scrape_all_urls()

    print(f"Scraped {len(documents)} URLs")

    all_chunks = []
    all_metadatas = []
    all_ids = []

    for idx, doc in enumerate(documents):
        chunks = chunk_text(doc["content"])
        for chunk_idx, chunk in enumerate(chunks):
            all_chunks.append(chunk)
            all_metadatas.append({"url": doc["url"], "chunk": chunk_idx})
            all_ids.append(f"doc_{idx}_chunk_{chunk_idx}")

    print(f"Created {len(all_chunks)} chunks")

    embedder = get_embedder()
    embeddings = embedder.encode(all_chunks, show_progress_bar=True).tolist()

    print(f"Generated {len(embeddings)} embeddings")

    collection = await get_collection()

    existing_count = collection.count()
    if existing_count > 0:
        collection.delete(ids=[f"doc_{i}_chunk_{j}" for i in range(20) for j in range(100)])

    collection.add(
        embeddings=embeddings,
        documents=all_chunks,
        metadatas=all_metadatas,
        ids=all_ids
    )

    print(f"Added {len(all_chunks)} documents to collection")
    return {"status": "success", "chunks": len(all_chunks)}
