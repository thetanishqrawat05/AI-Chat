from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from pathlib import Path
import os

from backend.database import init_db
from backend.routes import auth, chat, history, feedback, admin, status

limiter = Limiter(key_func=get_remote_address)
app = FastAPI(title="GitLab AI Assistant v2")
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(chat.router)
app.include_router(history.router)
app.include_router(feedback.router)
app.include_router(admin.router)
app.include_router(status.router)

@app.on_event("startup")
async def startup_event():
    await init_db()
    print("Database initialized")

    try:
        from backend.embeddings import get_collection
        collection = await get_collection()
        doc_count = collection.count()

        if doc_count == 0:
            print("No documents in collection. Run reindex to populate.")
        else:
            print(f"Collection has {doc_count} documents")
    except Exception as e:
        print(f"Error checking collection: {e}")

dist_path = Path(__file__).parent.parent / "dist"

if dist_path.exists():
    app.mount("/assets", StaticFiles(directory=str(dist_path / "assets")), name="assets")

    @app.get("/{full_path:path}")
    async def serve_frontend(full_path: str):
        if full_path.startswith("api/"):
            return {"error": "Not found"}

        file_path = dist_path / full_path
        if file_path.is_file():
            return FileResponse(file_path)

        return FileResponse(dist_path / "index.html")
else:
    @app.get("/")
    async def root():
        return {"message": "GitLab AI Assistant v2 - Backend Running. Build frontend with: npm run build"}
