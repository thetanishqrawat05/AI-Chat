import os
from typing import List, Dict, AsyncGenerator
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.schema import SystemMessage, HumanMessage, AIMessage
from backend.embeddings import query_documents

async def stream_rag_response(
    query: str,
    collection,
    chat_history: List[Dict[str, str]],
    user_id: int
) -> AsyncGenerator:
    try:
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            yield "Error: GEMINI_API_KEY not configured"
            return

        results = query_documents(query, n_results=5)

        context_docs = results['documents'][0] if results['documents'] else []
        metadatas = results['metadatas'][0] if results['metadatas'] else []

        context = "\n\n".join([
            f"[Source: {meta.get('url', 'Unknown')}]\n{doc}"
            for doc, meta in zip(context_docs, metadatas)
        ])

        sources = list(set([meta.get('url', '') for meta in metadatas if meta.get('url')]))

        system_prompt = f"""You are a helpful AI assistant for GitLab employees. You answer questions about GitLab's handbook, values, processes, and product direction.

Use the following context from GitLab's documentation to answer questions. Be specific and cite information from the context when relevant. If the context doesn't contain enough information, say so honestly.

Context:
{context}

Guidelines:
- Be concise but thorough
- Use examples from the context when helpful
- If you're unsure, acknowledge it
- Format your response with markdown for readability"""

        messages = [SystemMessage(content=system_prompt)]

        for msg in chat_history[-6:]:
            if msg.get("role") == "user":
                messages.append(HumanMessage(content=msg.get("content", "")))
            elif msg.get("role") == "assistant":
                messages.append(AIMessage(content=msg.get("content", "")))

        messages.append(HumanMessage(content=query))

        llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=api_key,
            streaming=True,
            temperature=0.7
        )

        full_response = ""
        token_count = 0

        async for chunk in llm.astream(messages):
            if hasattr(chunk, 'content') and chunk.content:
                full_response += chunk.content
                token_count += 1
                yield chunk.content

        yield {
            "sources": sources,
            "tokens": token_count
        }

    except Exception as e:
        error_msg = f"Error in RAG pipeline: {str(e)}"
        print(error_msg)
        yield error_msg
