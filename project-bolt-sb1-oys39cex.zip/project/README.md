# GitLab AI Assistant v2

A production-grade RAG chatbot for GitLab employees to query the GitLab Handbook and Direction pages. This is a major upgrade over v1 with full authentication, streaming responses, persistent chat history, feedback system, and admin dashboard.

## Features

### Core Features
- **RAG-Powered Answers**: Uses Gemini 1.5 Flash with ChromaDB vector store for accurate responses
- **Streaming Responses**: Real-time SSE streaming for better UX
- **20 GitLab URLs**: Comprehensive knowledge base covering Handbook and Direction pages

### Authentication & Security
- **JWT Authentication**: Secure email/password login system
- **Password Requirements**: Strong password validation (8+ chars, uppercase, number, special char)
- **Row-Level Security**: User data isolation in SQLite database
- **Rate Limiting**: Prevents abuse (20 req/min for chat, configurable for other endpoints)

### Chat Features
- **Persistent History**: All conversations saved to SQLite
- **Chat Management**: View, load, and delete past conversations
- **AI Follow-Up Questions**: Gemini generates 3 contextual follow-ups after each response
- **Message Feedback**: Thumbs up/down system for response quality
- **Copy & Export**: Copy individual messages or export entire chats as Markdown
- **Source Attribution**: Every answer shows which Handbook/Direction pages were used

### Admin Dashboard
- **System Statistics**: Users, conversations, messages, indexed documents
- **Feedback Analytics**: Positive feedback rate tracking
- **Top Questions**: Most asked questions in last 7 days
- **Re-Index Control**: Trigger knowledge base re-scraping with confirmation

### UI/UX
- **Dark Premium Design**: Polished dark theme with orange/purple accents
- **Responsive Layout**: Works on desktop and mobile
- **Smooth Animations**: Framer Motion transitions throughout
- **Markdown Support**: Code blocks, lists, links properly rendered with `react-markdown` + `remark-gfm`
- **Password Strength Meter**: Real-time visual feedback during registration
- **Typing Indicators**: Shows when AI is thinking

## Tech Stack

### Backend
- **FastAPI** - Modern Python web framework with SSE support
- **LangChain + Gemini 1.5 Flash** - RAG pipeline with streaming
- **ChromaDB** - Vector database for embeddings
- **SQLite + aiosqlite** - Lightweight persistent storage
- **sentence-transformers** - all-MiniLM-L6-v2 embeddings (lazy-loaded)
- **python-jose** - JWT token handling
- **passlib[bcrypt]** - Password hashing
- **slowapi** - Rate limiting middleware
- **httpx + BeautifulSoup4** - Web scraping

### Frontend
- **React 18 + Vite** - Modern React with fast builds
- **TailwindCSS** - Utility-first styling
- **Framer Motion** - Smooth animations
- **Axios** - HTTP client
- **react-markdown + remark-gfm** - Markdown rendering with GitHub Flavored Markdown

## Installation

### Prerequisites
- Python 3.11+
- Node.js 18+
- Gemini API Key (get from https://aistudio.google.com/app/apikey)

### Quick Start

1. **Clone and install**:
```bash
npm install
pip install -r backend/requirements.txt
```

2. **Set environment variables**:
```bash
cp .env.example .env
# Edit .env and add your GEMINI_API_KEY
```

3. **Build and run**:
```bash
./start.sh
```

The app will be available at `http://localhost:8000`

### Default Admin Account
- **Email**: admin@gitlab.com
- **Password**: Admin@12345

**⚠️ Change this password immediately in production!**

## Project Structure

```
gitlab-ai-assistant/
├── backend/
│   ├── main.py              # FastAPI app with CORS & routes
│   ├── auth.py              # JWT authentication logic
│   ├── database.py          # SQLite setup + queries
│   ├── scraper.py           # Scrapes 20 GitLab URLs
│   ├── embeddings.py        # ChromaDB + sentence-transformers (lazy-loaded)
│   ├── rag_pipeline.py      # LangChain streaming with proper message history
│   ├── routes/
│   │   ├── auth.py          # /api/auth/login, /register, /me
│   │   ├── chat.py          # /api/chat/stream (SSE), /followups
│   │   ├── history.py       # /api/history/conversations
│   │   ├── feedback.py      # /api/feedback
│   │   ├── admin.py         # /api/admin/stats, /reindex
│   │   └── status.py        # /api/status
│   └── requirements.txt
├── src/
│   ├── App.jsx              # Main app component
│   ├── main.jsx             # React entry point
│   ├── context/
│   │   └── AuthContext.jsx  # Global auth state
│   ├── pages/
│   │   ├── LoginPage.jsx    # Login/Register with tabs
│   │   └── ChatPage.jsx     # Main chat interface
│   └── components/
│       ├── Header.jsx       # Status, user menu, admin button, export
│       ├── Sidebar.jsx      # Suggestions + data sources
│       ├── ChatWindow.jsx   # Message display with follow-ups
│       ├── MessageBubble.jsx  # Individual message with copy + feedback
│       ├── InputBar.jsx     # Message input with streaming logic
│       ├── TypingIndicator.jsx
│       ├── SourceCard.jsx
│       ├── FeedbackButtons.jsx  # Thumbs up/down
│       ├── FollowUpSuggestions.jsx
│       ├── HistorySidebar.jsx   # Past conversations
│       └── AdminPanel.jsx   # Admin dashboard modal
├── start.sh
├── .env.example
└── README.md
```

## API Endpoints

### Public
- `GET /api/status` - System health check

### Authentication
- `POST /api/auth/register` - Create new user
- `POST /api/auth/login` - Login with email/password
- `GET /api/auth/me` - Get current user (protected)
- `POST /api/auth/logout` - Logout (client-side token removal)

### Chat (Protected)
- `POST /api/chat/stream` - Streaming chat response (SSE)
- `POST /api/chat/followups` - Generate 3 follow-up questions
- `GET /api/chat/suggestions` - Get starter questions

### History (Protected)
- `GET /api/history/conversations` - List user's conversations
- `GET /api/history/conversations/{id}/messages` - Get conversation messages
- `DELETE /api/history/conversations/{id}` - Delete conversation

### Feedback (Protected)
- `POST /api/feedback` - Submit thumbs up/down (rating: 1 or -1)
- `GET /api/feedback/stats` - Get feedback statistics (admin only)

### Admin (Protected, Admin Only)
- `GET /api/admin/stats` - System statistics
- `POST /api/admin/reindex` - Trigger knowledge base re-scraping

## Configuration

### Environment Variables
```bash
GEMINI_API_KEY=your_gemini_api_key_here  # Required
JWT_SECRET_KEY=your_random_secret         # Optional (auto-generated if missing)
```

### Rate Limits
Configured in `backend/main.py`:
- Chat streaming: 20 requests/minute per user
- Registration: 5 per hour per IP
- Login: 10 per hour per IP
- Other endpoints: 60 per minute per IP

### Knowledge Base URLs
Edit `GITLAB_URLS` in `backend/scraper.py` to customize which pages are indexed.

## Data Storage

### SQLite Database
Located at `backend/gitlab_ai.db` with 4 tables:
- **users** - User accounts with hashed passwords
- **conversations** - Chat sessions
- **messages** - Individual messages with sources
- **feedback** - Thumbs up/down ratings

### ChromaDB
Vector embeddings stored in `backend/chroma_db/` directory.

## Development

### Run Backend Only
```bash
cd backend
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### Run Frontend Dev Server
```bash
npm run dev
```

### Rebuild Knowledge Base
Use the admin dashboard "Re-index Knowledge Base" button, or run:
```python
import asyncio
from backend.scraper import scrape_and_embed
asyncio.run(scrape_and_embed())
```

## Production Deployment

1. **Build frontend**:
```bash
npm run build
```

2. **Set strong JWT secret**:
```bash
export JWT_SECRET_KEY=$(openssl rand -hex 32)
```

3. **Change admin password** via SQL or create new admin user

4. **Run with production server**:
```bash
cd backend
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

5. **Set up reverse proxy** (nginx/Caddy) for HTTPS

6. **Configure backups** for `gitlab_ai.db` and `chroma_db/`

## Troubleshooting

### "GEMINI_API_KEY not configured"
Add your Gemini API key to `.env` file or set as environment variable.

### Rate limit exceeded
Wait 60 seconds or adjust limits in `backend/main.py`.

### No documents in collection
Run re-index from admin dashboard or run scraper manually.

### Build fails with "Cannot find module"
Ensure all dependencies are installed:
```bash
npm install
pip install -r backend/requirements.txt
```

### Import errors (sentence-transformers)
The embedder is lazy-loaded on first use. Wait for initial scraping to complete.

## Security Notes

- **Passwords** are hashed with bcrypt
- **JWT tokens** expire after 24 hours
- **Rate limiting** prevents brute force attacks
- **SQLite** provides user isolation (conversation ownership checks)
- **No secrets in frontend** code or logs

## License

This project is for internal GitLab use. See GitLab's internal licensing policies.

## Support

For issues or questions, contact the engineering team or open an issue in the internal repository.

---

Built with ❤️ for GitLab
