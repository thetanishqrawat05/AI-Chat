import { useState, useEffect } from 'react';
import Header from '../components/Header';
import Sidebar from '../components/Sidebar';
import ChatWindow from '../components/ChatWindow';
import HistorySidebar from '../components/HistorySidebar';
import InputBar from '../components/InputBar';
import AdminPanel from '../components/AdminPanel';
import { useAuth } from '../context/AuthContext';

export default function ChatPage() {
  const { token } = useAuth();
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [showHistory, setShowHistory] = useState(true);
  const [currentConversation, setCurrentConversation] = useState(null);
  const [followUpSuggestions, setFollowUpSuggestions] = useState([]);

  const handleSendMessage = (message) => {
    setMessages(prev => [...prev, { id: Date.now(), role: 'user', content: message }]);
    setIsLoading(true);
  };

  const handleNewChat = () => {
    setMessages([]);
    setCurrentConversation(null);
    setFollowUpSuggestions([]);
  };

  const handleLoadConversation = async (conversationId) => {
    try {
      const response = await fetch(`/api/history/conversations/${conversationId}/messages`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await response.json();
      setMessages(data.messages);
      setCurrentConversation(conversationId);
      setFollowUpSuggestions([]);
    } catch (error) {
      console.error('Error loading conversation:', error);
    }
  };

  return (
    <div className="h-screen flex flex-col bg-gray-900">
      <Header onShowAdmin={() => setShowAdmin(true)} />

      <div className="flex-1 flex overflow-hidden">
        {showHistory && (
          <HistorySidebar
            onLoadConversation={handleLoadConversation}
            onNewChat={handleNewChat}
            currentConversation={currentConversation}
          />
        )}

        <div className="flex-1 flex flex-col">
          <ChatWindow
            messages={messages}
            isLoading={isLoading}
            followUpSuggestions={followUpSuggestions}
            onFollowUp={handleSendMessage}
          />

          <InputBar
            onSendMessage={handleSendMessage}
            disabled={isLoading}
            currentConversation={currentConversation}
            messages={messages}
            setMessages={setMessages}
            setIsLoading={setIsLoading}
            setFollowUpSuggestions={setFollowUpSuggestions}
          />
        </div>

        <Sidebar />
      </div>

      {showAdmin && <AdminPanel onClose={() => setShowAdmin(false)} />}
    </div>
  );
}
