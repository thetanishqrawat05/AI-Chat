import { useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, Check, User, Bot } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import FeedbackButtons from './FeedbackButtons';
import SourceCard from './SourceCard';
import { useAuth } from '../context/AuthContext';

export default function MessageBubble({ message, sources }) {
  const { isAuthenticated } = useAuth();
  const [copied, setCopied] = useState(false);
  const [showToolbar, setShowToolbar] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const isUser = message.role === 'user';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex gap-4 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
      onMouseEnter={() => setShowToolbar(true)}
      onMouseLeave={() => setShowToolbar(false)}
    >
      <div
        className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
          isUser ? 'bg-gradient-to-br from-orange-500 to-orange-600' : 'bg-gradient-to-br from-purple-500 to-purple-600'
        }`}
      >
        {isUser ? <User className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-white" />}
      </div>

      <div className={`flex-1 ${isUser ? 'flex flex-col items-end' : ''}`}>
        <div
          className={`inline-block max-w-4xl rounded-2xl px-6 py-4 ${
            isUser
              ? 'bg-orange-500/20 border border-orange-500/30'
              : 'bg-gray-700/50 border border-gray-600'
          }`}
        >
          {isUser ? (
            <p className="text-white whitespace-pre-wrap">{message.content}</p>
          ) : (
            <div className="prose prose-invert max-w-none">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                  code: ({ inline, children, ...props }) => (
                    inline ? (
                      <code className="px-2 py-1 bg-gray-800 rounded text-orange-400" {...props}>
                        {children}
                      </code>
                    ) : (
                      <code className="block p-4 bg-gray-800 rounded-lg overflow-x-auto" {...props}>
                        {children}
                      </code>
                    )
                  ),
                  p: ({ children }) => <p className="text-gray-200 mb-3 last:mb-0">{children}</p>,
                  ul: ({ children }) => <ul className="list-disc list-inside space-y-1 text-gray-200">{children}</ul>,
                  ol: ({ children }) => <ol className="list-decimal list-inside space-y-1 text-gray-200">{children}</ol>,
                  strong: ({ children }) => <strong className="text-white font-semibold">{children}</strong>,
                  a: ({ href, children }) => (
                    <a href={href} className="text-orange-400 hover:text-orange-300 underline" target="_blank" rel="noopener noreferrer">
                      {children}
                    </a>
                  ),
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>
          )}
        </div>

        {showToolbar && (
          <motion.div
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex items-center gap-2 mt-2 ${isUser ? 'justify-end' : ''}`}
          >
            <button
              onClick={handleCopy}
              className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-all flex items-center gap-1 text-sm"
              title="Copy to clipboard"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-green-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy</span>
                </>
              )}
            </button>

            {!isUser && isAuthenticated && message.id && (
              <FeedbackButtons messageId={message.id} />
            )}
          </motion.div>
        )}

        {!isUser && sources && sources.length > 0 && (
          <div className="mt-4 space-y-2">
            <p className="text-sm text-gray-400 font-medium">Sources:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {sources.map((url, idx) => (
                <SourceCard key={idx} url={url} />
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
