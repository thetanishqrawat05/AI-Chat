import { useState, useEffect } from 'react';
import { Shield, LogOut, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../context/AuthContext';

export default function Header({ onShowAdmin }) {
  const { user, logout, isAdmin } = useAuth();
  const [status, setStatus] = useState({ status: 'loading', message: 'Connecting...' });
  const [showUserMenu, setShowUserMenu] = useState(false);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const response = await fetch('/api/status');
        const data = await response.json();
        setStatus(data);
      } catch (error) {
        setStatus({ status: 'error', message: 'Connection error' });
      }
    };

    fetchStatus();
    const interval = setInterval(fetchStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleExport = () => {
    const chatContent = `# GitLab AI Chat Export\n\nExported: ${new Date().toLocaleString()}\n\n`;
    const blob = new Blob([chatContent], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gitlab-ai-chat-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const statusColors = {
    online: 'bg-green-500',
    needs_config: 'bg-yellow-500',
    error: 'bg-red-500',
    loading: 'bg-gray-500'
  };

  const userInitial = user?.username?.[0]?.toUpperCase() || 'U';

  return (
    <header className="bg-gray-800/90 backdrop-blur-xl border-b border-gray-700 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-500/10 rounded-lg">
              <svg className="w-6 h-6 text-orange-500" fill="currentColor" viewBox="0 0 24 24">
                <path d="M23.546 10.93L13.067.452c-.604-.603-1.582-.603-2.188 0L.397 10.93c-.528.531-.528 1.387 0 1.917l10.48 10.479c.604.604 1.582.604 2.186 0l10.48-10.479c.53-.53.53-1.386.003-1.917zm-11.544 8.54l-6.34-6.34 1.992-1.992 4.348 4.348 9.34-9.34 1.992 1.992-11.332 11.332z"/>
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">GitLab AI Assistant</h1>
              <p className="text-xs text-gray-400">v2.0</p>
            </div>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 bg-gray-900/50 rounded-lg border border-gray-700">
            <div className={`w-2 h-2 rounded-full ${statusColors[status.status || 'loading']}`} />
            <span className="text-sm text-gray-300">{status.message}</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExport}
            className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors"
            title="Export chat"
          >
            <Download className="w-5 h-5" />
          </button>

          {isAdmin && (
            <button
              onClick={onShowAdmin}
              className="p-2 text-orange-400 hover:text-orange-300 hover:bg-orange-500/10 rounded-lg transition-colors"
              title="Admin panel"
            >
              <Shield className="w-5 h-5" />
            </button>
          )}

          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="w-10 h-10 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center text-white font-bold hover:scale-105 transition-transform"
            >
              {userInitial}
            </button>

            <AnimatePresence>
              {showUserMenu && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute right-0 mt-2 w-64 bg-gray-800 rounded-lg border border-gray-700 shadow-xl overflow-hidden z-50"
                >
                  <div className="p-4 border-b border-gray-700">
                    <p className="text-white font-medium">{user?.username}</p>
                    <p className="text-sm text-gray-400">{user?.email}</p>
                    {isAdmin && (
                      <span className="inline-block mt-2 px-2 py-1 bg-orange-500/20 text-orange-400 text-xs rounded">
                        Admin
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      logout();
                    }}
                    className="w-full px-4 py-3 text-left text-red-400 hover:bg-gray-700/50 flex items-center gap-2 transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    Logout
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 bg-purple-500/10 rounded-lg border border-purple-500/20">
            <svg className="w-4 h-4 text-purple-400" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
            </svg>
            <span className="text-xs text-purple-300 font-medium">Gemini 1.5</span>
          </div>
        </div>
      </div>
    </header>
  );
}
