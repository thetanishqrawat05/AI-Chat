import { useState } from 'react';
import { Send } from 'lucide-react';
import { motion } from 'framer-motion';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

export default function InputBar({
  onSendMessage,
  disabled,
  currentConversation,
  messages,
  setMessages,
  setIsLoading,
  setFollowUpSuggestions
}) {
  const { token, user } = useAuth();
  const [input, setInput] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim() || disabled) return;

    const userMessage = input.trim();
    setInput('');
    onSendMessage(userMessage);

    try {
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          message: userMessage,
          conversation_id: currentConversation,
          history: messages.slice(-6).map(m => ({ role: m.role, content: m.content }))
        })
      });

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let assistantMessage = { id: Date.now() + 1, role: 'assistant', content: '', sources: [] };
      let buffer = '';

      setMessages(prev => [...prev, assistantMessage]);

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop();

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));

              if (data.token) {
                assistantMessage.content += data.token;
                setMessages(prev => {
                  const updated = [...prev];
                  updated[updated.length - 1] = { ...assistantMessage };
                  return updated;
                });
              }

              if (data.done) {
                assistantMessage.sources = data.sources || [];
                assistantMessage.id = data.message_id || assistantMessage.id;
                setMessages(prev => {
                  const updated = [...prev];
                  updated[updated.length - 1] = { ...assistantMessage };
                  return updated;
                });

                try {
                  const followUpRes = await axios.post(
                    '/api/chat/followups',
                    { question: userMessage, answer: assistantMessage.content },
                    { headers: { Authorization: `Bearer ${token}` } }
                  );
                  setFollowUpSuggestions(followUpRes.data.suggestions || []);
                } catch (err) {
                  console.error('Error fetching follow-ups:', err);
                }
              }

              if (data.error) {
                console.error('Streaming error:', data.error);
              }
            } catch (err) {
              console.error('Error parsing SSE:', err);
            }
          }
        }
      }
    } catch (error) {
      console.error('Chat error:', error);
      setMessages(prev => [
        ...prev,
        {
          id: Date.now() + 2,
          role: 'assistant',
          content: 'Sorry, I encountered an error. Please try again.',
          sources: []
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const userInitial = user?.username?.[0]?.toUpperCase() || 'U';

  return (
    <div className="border-t border-gray-700 bg-gray-800/90 backdrop-blur-xl p-4">
      <form onSubmit={handleSubmit} className="max-w-5xl mx-auto">
        <div className="flex items-end gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0">
            {userInitial}
          </div>

          <div className="flex-1 relative">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask me anything about GitLab..."
              disabled={disabled}
              className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-orange-500 transition-colors resize-none"
              rows={1}
              style={{
                minHeight: '48px',
                maxHeight: '200px',
                height: 'auto'
              }}
              onInput={(e) => {
                e.target.style.height = 'auto';
                e.target.style.height = e.target.scrollHeight + 'px';
              }}
            />
          </div>

          <motion.button
            type="submit"
            disabled={!input.trim() || disabled}
            className="p-3 bg-orange-500 hover:bg-orange-600 disabled:bg-gray-700 disabled:cursor-not-allowed text-white rounded-xl transition-colors flex-shrink-0"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Send className="w-5 h-5" />
          </motion.button>
        </div>

        <p className="text-xs text-gray-500 mt-2 text-center">
          Press Enter to send, Shift+Enter for new line
        </p>
      </form>
    </div>
  );
}
