import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FileText, Sparkles } from 'lucide-react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

export default function Sidebar() {
  const { token } = useAuth();
  const [suggestions, setSuggestions] = useState([]);

  useEffect(() => {
    const fetchSuggestions = async () => {
      try {
        const response = await axios.get('/api/chat/suggestions', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setSuggestions(response.data.suggestions || []);
      } catch (error) {
        console.error('Error fetching suggestions:', error);
      }
    };

    fetchSuggestions();
  }, [token]);

  const sources = [
    { name: 'GitLab Handbook', url: 'https://handbook.gitlab.com', count: 10 },
    { name: 'Product Direction', url: 'https://about.gitlab.com/direction', count: 10 }
  ];

  return (
    <div className="w-80 bg-gray-800/50 border-l border-gray-700 p-6 overflow-y-auto">
      <div className="space-y-6">
        <div>
          <h3 className="text-sm font-semibold text-gray-400 mb-3 flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            Suggested Questions
          </h3>
          <div className="space-y-2">
            {suggestions.map((suggestion, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="p-3 bg-gray-700/30 hover:bg-gray-700/50 rounded-lg text-sm text-gray-300 hover:text-white transition-all cursor-pointer border border-gray-600 hover:border-orange-500/50"
              >
                {suggestion}
              </motion.div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-gray-400 mb-3 flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Data Sources
          </h3>
          <div className="space-y-2">
            {sources.map((source, idx) => (
              <div
                key={idx}
                className="p-3 bg-gray-700/30 rounded-lg border border-gray-600"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-white">{source.name}</span>
                  <span className="text-xs text-gray-400">{source.count} pages</span>
                </div>
                <a
                  href={source.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-orange-400 hover:text-orange-300 truncate block"
                >
                  {source.url}
                </a>
              </div>
            ))}
          </div>
        </div>

        <div className="p-4 bg-gray-700/30 rounded-lg border border-gray-600">
          <h4 className="text-sm font-medium text-white mb-2">About this Assistant</h4>
          <p className="text-xs text-gray-400 leading-relaxed">
            This AI assistant is powered by Gemini 1.5 Flash and trained on GitLab's official handbook
            and product direction documentation. Ask me anything about GitLab's values, processes,
            engineering practices, or product roadmap.
          </p>
        </div>
      </div>
    </div>
  );
}
