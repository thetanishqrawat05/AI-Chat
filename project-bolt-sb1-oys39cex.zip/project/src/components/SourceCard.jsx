import { ExternalLink } from 'lucide-react';
import { motion } from 'framer-motion';

export default function SourceCard({ url }) {
  const getDisplayName = (url) => {
    if (url.includes('handbook.gitlab.com')) {
      const parts = url.split('/handbook/');
      return parts[1] ? `Handbook: ${parts[1].split('/')[0]}` : 'GitLab Handbook';
    }
    if (url.includes('about.gitlab.com/direction')) {
      const parts = url.split('/direction/');
      return parts[1] ? `Direction: ${parts[1].split('/')[0]}` : 'Product Direction';
    }
    return url;
  };

  return (
    <motion.a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-2 p-3 bg-gray-800/50 hover:bg-gray-700/50 border border-gray-600 hover:border-orange-500/50 rounded-lg transition-all group"
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-white truncate">
          {getDisplayName(url)}
        </p>
        <p className="text-xs text-gray-400 truncate">{url}</p>
      </div>
      <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-orange-400 flex-shrink-0 transition-colors" />
    </motion.a>
  );
}
