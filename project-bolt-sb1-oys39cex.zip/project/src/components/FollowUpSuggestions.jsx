import { motion } from 'framer-motion';
import { Sparkles } from 'lucide-react';

export default function FollowUpSuggestions({ suggestions, onSelect }) {
  if (!suggestions || suggestions.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="mt-4 space-y-2"
    >
      <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
        <Sparkles className="w-4 h-4 text-orange-400" />
        <span>You might also ask:</span>
      </div>

      <div className="flex flex-wrap gap-2">
        {suggestions.map((suggestion, idx) => (
          <motion.button
            key={idx}
            onClick={() => onSelect(suggestion)}
            className="px-4 py-2 bg-gray-700/30 hover:bg-gray-700/50 border border-gray-600 hover:border-orange-500/50 rounded-full text-sm text-gray-300 hover:text-white transition-all"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {suggestion}
          </motion.button>
        ))}
      </div>
    </motion.div>
  );
}
