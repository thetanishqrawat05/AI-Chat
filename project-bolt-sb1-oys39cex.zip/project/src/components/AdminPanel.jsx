import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Users, MessageSquare, FileText, RefreshCw, ThumbsUp, ThumbsDown, TrendingUp } from 'lucide-react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

export default function AdminPanel({ onClose }) {
  const { token } = useAuth();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [reindexing, setReindexing] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await axios.get('/api/admin/stats', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleReindex = async () => {
    setReindexing(true);
    setShowConfirm(false);

    try {
      await axios.post('/api/admin/reindex', {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert('Re-indexing started! This will take a few minutes.');
    } catch (error) {
      alert('Error starting re-index: ' + error.message);
    } finally {
      setReindexing(false);
    }
  };

  const StatCard = ({ icon: Icon, label, value, color }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gray-700/30 rounded-xl p-6 border border-gray-600"
    >
      <div className="flex items-center justify-between mb-2">
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <span className="text-3xl font-bold text-white">{value}</span>
      </div>
      <p className="text-gray-400 text-sm">{label}</p>
    </motion.div>
  );

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-gray-800 rounded-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden shadow-2xl border border-gray-700"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="bg-gradient-to-r from-orange-500/10 to-purple-500/10 p-6 border-b border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white flex items-center gap-3">
                  <div className="p-2 bg-orange-500/20 rounded-lg">
                    <TrendingUp className="w-6 h-6 text-orange-400" />
                  </div>
                  Admin Dashboard
                </h2>
                <p className="text-gray-400 mt-1">System statistics and management</p>
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-700 rounded-lg transition-colors text-gray-400 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>

          <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
            {loading ? (
              <div className="flex items-center justify-center py-20">
                <div className="animate-spin w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full" />
              </div>
            ) : (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <StatCard
                    icon={Users}
                    label="Total Users"
                    value={stats?.total_users || 0}
                    color="bg-blue-500/20"
                  />
                  <StatCard
                    icon={MessageSquare}
                    label="Conversations"
                    value={stats?.total_conversations || 0}
                    color="bg-green-500/20"
                  />
                  <StatCard
                    icon={FileText}
                    label="Messages"
                    value={stats?.total_messages || 0}
                    color="bg-purple-500/20"
                  />
                  <StatCard
                    icon={FileText}
                    label="Documents Indexed"
                    value={stats?.documents_indexed || 0}
                    color="bg-orange-500/20"
                  />
                </div>

                <div className="bg-gray-700/30 rounded-xl p-6 border border-gray-600">
                  <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                    <ThumbsUp className="w-5 h-5 text-green-400" />
                    Feedback Statistics
                  </h3>
                  <div className="space-y-3">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-400 text-sm">Positive Feedback Rate</span>
                        <span className="text-white font-bold">
                          {((stats?.positive_feedback_rate || 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-green-500 to-emerald-500 h-2 rounded-full transition-all"
                          style={{ width: `${(stats?.positive_feedback_rate || 0) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-700/30 rounded-xl p-6 border border-gray-600">
                  <h3 className="text-lg font-semibold text-white mb-4">Top Questions (Last 7 Days)</h3>
                  <div className="space-y-2">
                    {stats?.top_questions && stats.top_questions.length > 0 ? (
                      stats.top_questions.map((question, idx) => (
                        <div
                          key={idx}
                          className="p-3 bg-gray-800/50 rounded-lg border border-gray-600 text-gray-300 text-sm"
                        >
                          {idx + 1}. {question}
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-400 text-sm">No questions yet</p>
                    )}
                  </div>
                </div>

                <div className="bg-gradient-to-br from-orange-500/10 to-red-500/10 rounded-xl p-6 border border-orange-500/30">
                  <h3 className="text-lg font-semibold text-white mb-2">Re-index Knowledge Base</h3>
                  <p className="text-gray-400 text-sm mb-4">
                    Re-scrape and re-embed all {' '}20 GitLab URLs. This process takes several minutes.
                  </p>

                  {!showConfirm ? (
                    <button
                      onClick={() => setShowConfirm(true)}
                      disabled={reindexing}
                      className="px-6 py-3 bg-orange-500 hover:bg-orange-600 disabled:bg-gray-700 disabled:cursor-not-allowed text-white rounded-lg transition-colors flex items-center gap-2"
                    >
                      <RefreshCw className={`w-5 h-5 ${reindexing ? 'animate-spin' : ''}`} />
                      {reindexing ? 'Re-indexing...' : 'Re-index Knowledge Base'}
                    </button>
                  ) : (
                    <div className="flex gap-3">
                      <button
                        onClick={handleReindex}
                        className="px-6 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors font-medium"
                      >
                        Confirm Re-index
                      </button>
                      <button
                        onClick={() => setShowConfirm(false)}
                        className="px-6 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
