import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import MessageBubble from './MessageBubble';
import TypingIndicator from './TypingIndicator';
import FollowUpSuggestions from './FollowUpSuggestions';

export default function ChatWindow({ messages, isLoading, followUpSuggestions, onFollowUp }) {
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6">
      {messages.length === 0 && !isLoading ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto text-center py-20"
        >
          <div className="inline-block p-6 bg-gradient-to-br from-orange-500/10 to-purple-500/10 rounded-3xl mb-6">
            <svg className="w-24 h-24 text-orange-500" fill="currentColor" viewBox="0 0 24 24">
              <path d="M23.546 10.93L13.067.452c-.604-.603-1.582-.603-2.188 0L.397 10.93c-.528.531-.528 1.387 0 1.917l10.48 10.479c.604.604 1.582.604 2.186 0l10.48-10.479c.53-.53.53-1.386.003-1.917zm-11.544 8.54l-6.34-6.34 1.992-1.992 4.348 4.348 9.34-9.34 1.992 1.992-11.332 11.332z"/>
            </svg>
          </div>
          <h2 className="text-3xl font-bold text-white mb-4">
            Welcome to GitLab AI Assistant v2
          </h2>
          <p className="text-gray-400 text-lg mb-8">
            Ask me anything about GitLab's handbook, values, processes, and product direction.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-3xl mx-auto">
            {[
              'What are GitLab\'s core values?',
              'How does GitLab handle remote work?',
              'Tell me about GitLab\'s product direction',
              'What are GitLab\'s engineering practices?'
            ].map((question, idx) => (
              <motion.button
                key={idx}
                onClick={() => onFollowUp(question)}
                className="p-4 bg-gray-800/50 hover:bg-gray-700/50 border border-gray-700 hover:border-orange-500/50 rounded-xl text-left text-gray-300 hover:text-white transition-all"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {question}
              </motion.button>
            ))}
          </div>
        </motion.div>
      ) : (
        <div className="max-w-5xl mx-auto space-y-6">
          {messages.map((message, idx) => (
            <MessageBubble
              key={message.id || idx}
              message={message}
              sources={message.sources}
            />
          ))}

          {isLoading && <TypingIndicator />}

          {!isLoading && followUpSuggestions.length > 0 && (
            <FollowUpSuggestions
              suggestions={followUpSuggestions}
              onSelect={onFollowUp}
            />
          )}

          <div ref={messagesEndRef} />
        </div>
      )}
    </div>
  );
}
