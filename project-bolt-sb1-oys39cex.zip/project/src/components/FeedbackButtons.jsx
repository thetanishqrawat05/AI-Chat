import { useState } from 'react';
import { ThumbsUp, ThumbsDown } from 'lucide-react';
import { motion } from 'framer-motion';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

export default function FeedbackButtons({ messageId }) {
  const { token } = useAuth();
  const [feedback, setFeedback] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleFeedback = async (rating) => {
    if (loading) return;

    setLoading(true);
    try {
      await axios.post(
        '/api/feedback',
        { message_id: messageId, rating },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setFeedback(rating);
    } catch (error) {
      console.error('Error submitting feedback:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center gap-2">
      <motion.button
        onClick={() => handleFeedback(1)}
        disabled={loading}
        className={`p-2 rounded-lg transition-all ${
          feedback === 1
            ? 'bg-green-500/20 text-green-400'
            : 'text-gray-400 hover:text-green-400 hover:bg-green-500/10'
        }`}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        title="Helpful"
      >
        <ThumbsUp className="w-4 h-4" />
      </motion.button>

      <motion.button
        onClick={() => handleFeedback(-1)}
        disabled={loading}
        className={`p-2 rounded-lg transition-all ${
          feedback === -1
            ? 'bg-red-500/20 text-red-400'
            : 'text-gray-400 hover:text-red-400 hover:bg-red-500/10'
        }`}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        title="Not helpful"
      >
        <ThumbsDown className="w-4 h-4" />
      </motion.button>
    </div>
  );
}
